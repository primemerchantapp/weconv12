"use client"

import { type ReactNode, useEffect, useState } from "react"
import { Header } from "./header"
import { Navbar } from "./navbar"

interface LayoutProps {
  children: ReactNode
}

export function Layout({ children }: LayoutProps) {
  const [theme, setTheme] = useState("light")

  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [theme])

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light")
  }

  return (
    <div className="flex min-h-screen flex-col bg-white text-gray-900 dark:bg-gray-900 dark:text-gray-100">
      <Header toggleTheme={toggleTheme} theme={theme} />
      <main className="flex-1 pb-16">
        <div className="mx-auto max-w-screen-xl px-4">{children}</div>
      </main>
      <Navbar />
    </div>
  )
}

