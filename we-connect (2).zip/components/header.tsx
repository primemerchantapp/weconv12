"use client"

import { Bell, Menu, Search, Sun, Moon } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useState } from "react"
import { SideMenu } from "./side-menu"
import { Button } from "./ui/button"

interface HeaderProps {
  toggleTheme: () => void
  theme: string
}

export function Header({ toggleTheme, theme }: HeaderProps) {
  const [isSideMenuOpen, setIsSideMenuOpen] = useState(false)

  return (
    <header className="w-full border-b bg-white dark:bg-gray-800 dark:border-gray-700">
      <div className="mx-auto flex h-16 max-w-screen-xl items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            className="p-2 text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-gray-100"
            onClick={() => setIsSideMenuOpen(true)}
          >
            <Menu className="h-6 w-6" />
          </Button>
          <div className="relative w-full max-w-md">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full rounded-full border border-gray-200 bg-gray-100 py-2 pl-8 pr-4 text-sm outline-none focus:border-blue-300 focus:ring-1 focus:ring-blue-300 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:focus:border-blue-500 dark:focus:ring-blue-500"
            />
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button className="rounded-full p-2 text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700">
            <Bell className="h-5 w-5" />
          </button>
          <button
            onClick={toggleTheme}
            className="rounded-full p-2 text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
          >
            {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
          </button>
          <Link href="/profile">
            <div className="overflow-hidden rounded-full border-2 border-gray-200 dark:border-gray-600">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="Profile"
                width={40}
                height={40}
                className="h-10 w-10 object-cover"
              />
            </div>
          </Link>
        </div>
      </div>
      <SideMenu isOpen={isSideMenuOpen} onClose={() => setIsSideMenuOpen(false)} />
    </header>
  )
}

