"use client"

import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { PenToolIcon as Tool, Users, FileText, LayoutTemplate, Plug, LogOut } from "lucide-react"
import Link from "next/link"

interface SideMenuProps {
  isOpen: boolean
  onClose: () => void
}

export function SideMenu({ isOpen, onClose }: SideMenuProps) {
  const menuItems = [
    { name: "My Tools", icon: Tool, href: "/tools" },
    { name: "ConnectHub", icon: Users, href: "/connect-hub" },
    { name: "Contents", icon: FileText, href: "/contents" },
    { name: "Templates", icon: LayoutTemplate, href: "/templates" },
    { name: "Integration", icon: Plug, href: "/integration" },
  ]

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="left" className="w-[300px] sm:w-[400px]">
        <SheetHeader>
          <SheetTitle>Menu</SheetTitle>
        </SheetHeader>
        <ScrollArea className="h-[calc(100vh-8rem)] pb-10">
          <div className="flex flex-col space-y-3 py-4">
            {menuItems.map((item) => (
              <Link key={item.name} href={item.href} onClick={onClose}>
                <Button variant="ghost" className="w-full justify-start">
                  <item.icon className="mr-2 h-5 w-5" />
                  {item.name}
                </Button>
              </Link>
            ))}
          </div>
        </ScrollArea>
        <div className="absolute bottom-4 left-4 right-4">
          <Button variant="destructive" className="w-full" onClick={onClose}>
            <LogOut className="mr-2 h-5 w-5" />
            Logout
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}

