"use client"

import { Layout } from "@/components/layout"
import Image from "next/image"
import { Heart, MessageSquare, Share2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"

export default function CommunityPage() {
  return (
    <Layout>
      <div className="flex items-center justify-between py-6">
        <h1 className="text-3xl font-bold">Community</h1>
        <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">
          <span className="mr-1 text-lg">+</span> Create Post
        </Button>
      </div>

      <Tabs defaultValue="all-posts" className="mb-6">
        <TabsList className="grid w-full grid-cols-3 rounded-md bg-gray-100 dark:bg-gray-800">
          <TabsTrigger
            value="all-posts"
            className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
          >
            All Posts
          </TabsTrigger>
          <TabsTrigger
            value="following"
            className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
          >
            Following
          </TabsTrigger>
          <TabsTrigger
            value="trending"
            className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
          >
            Trending
          </TabsTrigger>
        </TabsList>
        <TabsContent value="all-posts">
          <div className="mt-4 rounded-lg border bg-white p-4 dark:bg-gray-800 dark:border-gray-700">
            <div className="mb-4 flex items-center gap-3">
              <Image
                src="/placeholder.svg?height=48&width=48"
                alt="Profile"
                width={48}
                height={48}
                className="rounded-full"
              />
              <div>
                <h3 className="font-semibold">Maria Santos</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">2 hours ago</p>
              </div>
            </div>
            <p className="mb-4">
              Just finished recording a new video series about content creation! Abangan niyo guys, may tips ako para
              kumita online 📹 ✨
            </p>
            <div className="mb-4 overflow-hidden rounded-md">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Content creation"
                width={600}
                height={400}
                className="w-full object-cover"
              />
            </div>
            <div className="flex justify-between">
              <button className="flex items-center gap-1 text-gray-600 dark:text-gray-300">
                <Heart className="h-5 w-5" />
                <span>24</span>
              </button>
              <button className="flex items-center gap-1 text-gray-600 dark:text-gray-300">
                <MessageSquare className="h-5 w-5" />
                <span>5</span>
              </button>
              <button className="flex items-center gap-1 text-gray-600 dark:text-gray-300">
                <Share2 className="h-5 w-5" />
                <span>Share</span>
              </button>
            </div>
          </div>
        </TabsContent>
        <TabsContent value="following">
          <div className="mt-4 rounded-lg border bg-white p-6 text-center dark:bg-gray-800 dark:border-gray-700">
            <p className="text-gray-500 dark:text-gray-400">Follow more people to see their posts here.</p>
          </div>
        </TabsContent>
        <TabsContent value="trending">
          <div className="mt-4 rounded-lg border bg-white p-6 text-center dark:bg-gray-800 dark:border-gray-700">
            <p className="text-gray-500 dark:text-gray-400">No trending posts at the moment.</p>
          </div>
        </TabsContent>
      </Tabs>
    </Layout>
  )
}

