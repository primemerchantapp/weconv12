"use client"

import { Layout } from "@/components/layout"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Image,
  Youtube,
  Video,
  Music,
  Maximize,
  Minimize,
  Smile,
  Film,
  MonitorSmartphone,
  MonitorUp,
  Subtitles,
  Palette,
  Calendar,
  CalendarClock,
  ImagePlus,
  Edit,
  FileVideo,
  ScanIcon as Scanner,
  FileType,
  Hash,
} from "lucide-react"

const tools = [
  { name: "Remove BG", icon: Image },
  { name: "YouTube Downloader", icon: Youtube },
  { name: "Basic Video Editor", icon: Video },
  { name: "Basic Audio Editor", icon: Music },
  { name: "Image Resizer", icon: Maximize },
  { name: "Image Compressor", icon: Minimize },
  { name: "Meme Generator", icon: Smile },
  { name: "GIF Maker", icon: Film },
  { name: "Screen Capture Tool", icon: MonitorSmartphone },
  { name: "Screen Recorder", icon: MonitorUp },
  { name: "Subtitle Generator", icon: Subtitles },
  { name: "Social Media Post Creator", icon: Palette },
  { name: "Social Media Scheduler", icon: Calendar },
  { name: "Content Calendar Tool", icon: CalendarClock },
  { name: "Stock Image Finder", icon: ImagePlus },
  { name: "Basic Photo Editor", icon: Edit },
  { name: "Video Compressor", icon: FileVideo },
  { name: "Document Scanner App", icon: Scanner },
  { name: "File Converter", icon: FileType },
  { name: "Hashtag Generator", icon: Hash },
]

export default function ToolsPage() {
  return (
    <Layout>
      <div className="py-6">
        <h1 className="text-3xl font-bold mb-6">My Tools</h1>

        <Tabs defaultValue="free" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="mytools">My Tools</TabsTrigger>
            <TabsTrigger value="free">Free</TabsTrigger>
            <TabsTrigger value="premium">Premium</TabsTrigger>
          </TabsList>
          <TabsContent value="mytools">
            <p className="text-gray-600 dark:text-gray-400">Your personal tools will appear here.</p>
          </TabsContent>
          <TabsContent value="free">
            <div className="grid grid-cols-3 gap-2 sm:gap-4">
              {tools.map((tool, index) => (
                <div
                  key={index}
                  className="flex flex-col items-center justify-center p-2 sm:p-3 bg-white dark:bg-gray-800 rounded-lg shadow hover:shadow-md transition-shadow"
                >
                  <tool.icon className="w-6 h-6 sm:w-8 sm:h-8 mb-1 sm:mb-2 text-blue-600 dark:text-blue-400" />
                  <span className="text-[10px] sm:text-xs text-center">{tool.name}</span>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="premium">
            <p className="text-gray-600 dark:text-gray-400">Premium tools will be available here.</p>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  )
}

