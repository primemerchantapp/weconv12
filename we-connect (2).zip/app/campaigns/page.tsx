"use client"

import { Layout } from "@/components/layout"
import Image from "next/image"
import { Clock, Tag, Users } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

export default function CampaignsPage() {
  return (
    <Layout>
      <div className="flex items-center justify-between py-6">
        <h1 className="text-3xl font-bold">Campaigns</h1>
        <Button
          variant="outline"
          className="bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
        >
          <span className="mr-1">📈</span> View All
        </Button>
      </div>

      <Tabs defaultValue="active" className="mb-6">
        <TabsList className="grid w-full grid-cols-3 rounded-md bg-gray-100 dark:bg-gray-800">
          <TabsTrigger
            value="active"
            className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
          >
            Active
          </TabsTrigger>
          <TabsTrigger
            value="completed"
            className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
          >
            Completed
          </TabsTrigger>
          <TabsTrigger
            value="my-campaigns"
            className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
          >
            My Campaigns
          </TabsTrigger>
        </TabsList>
        <TabsContent value="active">
          <div className="mt-4 space-y-6">
            <div className="rounded-lg border bg-white p-4 dark:bg-gray-800 dark:border-gray-700">
              <div className="mb-4 flex items-start gap-3">
                <Image
                  src="/placeholder.svg?height=60&width=60"
                  alt="Campaign"
                  width={60}
                  height={60}
                  className="rounded-full"
                />
                <div>
                  <h2 className="text-xl font-bold">Bagong Eco-Friendly Products</h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400">by Green Earth PH</p>
                </div>
              </div>
              <div className="mb-4 overflow-hidden rounded-md bg-gray-100 dark:bg-gray-700">
                <Image
                  src="/placeholder.svg?height=200&width=600"
                  alt="Campaign banner"
                  width={600}
                  height={200}
                  className="w-full object-cover"
                />
              </div>
              <div className="mb-4 space-y-2">
                <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
                  <Clock className="h-5 w-5" />
                  <span>14 days left</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
                  <Tag className="h-5 w-5" />
                  <span>Video + Photos</span>
                </div>
              </div>
              <p className="mb-4">
                Sumali sa aming campaign para i-promote ang mga sustainable products. Earn up to ₱5,000!
              </p>
              <div className="mb-2 flex flex-wrap gap-2">
                <span className="rounded-full bg-blue-100 px-3 py-1 text-sm text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                  Eco-Friendly
                </span>
                <span className="rounded-full bg-blue-100 px-3 py-1 text-sm text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                  Sustainability
                </span>
              </div>
              <div className="mb-2">
                <div className="mb-1 flex justify-between">
                  <span className="text-sm font-medium">Progress</span>
                  <span className="text-sm font-medium">75%</span>
                </div>
                <Progress value={75} className="h-2" />
              </div>
              <div className="mb-4 flex justify-between">
                <span className="text-sm">Goal: ₱50,000</span>
                <span className="text-sm">Raised: ₱37,500</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                  <span className="text-sm text-gray-500 dark:text-gray-400">120 participants</span>
                </div>
                <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">
                  Join Campaign
                </Button>
              </div>
            </div>

            <div className="rounded-lg border bg-white p-4 dark:bg-gray-800 dark:border-gray-700">
              <h2 className="text-xl font-bold">Education Support Program</h2>
              {/* Similar content structure as above */}
            </div>
          </div>
        </TabsContent>
        <TabsContent value="completed">
          <div className="mt-4 rounded-lg border bg-white p-6 text-center dark:bg-gray-800 dark:border-gray-700">
            <p className="text-gray-500 dark:text-gray-400">No completed campaigns yet.</p>
          </div>
        </TabsContent>
        <TabsContent value="my-campaigns">
          <div className="mt-4 rounded-lg border bg-white p-6 text-center dark:bg-gray-800 dark:border-gray-700">
            <p className="text-gray-500 dark:text-gray-400">You haven't joined any campaigns yet.</p>
            <Button className="mt-4 bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">
              Browse Campaigns
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </Layout>
  )
}

