import { Layout } from "@/components/layout"

export default function TemplatesPage() {
  return (
    <Layout>
      <div className="py-6">
        <h1 className="text-3xl font-bold">Templates</h1>
        <p className="mt-4">Browse and use various templates for your projects.</p>
      </div>
    </Layout>
  )
}

