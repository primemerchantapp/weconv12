"use client"

import { Layout } from "@/components/layout"
import Image from "next/image"
import { Filter, Search, ShoppingCart } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function ShopPage() {
  return (
    <Layout>
      <div className="flex items-center justify-between py-6">
        <h1 className="text-3xl font-bold">Shop</h1>
        <Button variant="outline" className="flex items-center gap-2 dark:border-gray-600 dark:text-gray-200">
          <ShoppingCart className="h-5 w-5" />
          <span>Cart (0)</span>
        </Button>
      </div>

      <div className="mb-4 rounded-lg border bg-white dark:bg-gray-800 dark:border-gray-700">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500 dark:text-gray-400" />
          <Input placeholder="Search products..." className="border-0 pl-10 dark:bg-gray-800 dark:text-gray-200" />
        </div>
      </div>

      <Button variant="outline" className="mb-4 w-full justify-center py-2 dark:border-gray-600 dark:text-gray-200">
        <Filter className="mr-2 h-5 w-5" />
        <span>Filter</span>
      </Button>

      <Tabs defaultValue="all" className="mb-6">
        <TabsList className="grid w-full grid-cols-3 rounded-md bg-gray-100 dark:bg-gray-800">
          <TabsTrigger
            value="all"
            className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
          >
            All
          </TabsTrigger>
          <TabsTrigger
            value="clothing"
            className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
          >
            Clothing
          </TabsTrigger>
          <TabsTrigger
            value="accessories"
            className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
          >
            Accessories
          </TabsTrigger>
        </TabsList>
        <TabsContent value="all">
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="rounded-lg border bg-white p-3 dark:bg-gray-800 dark:border-gray-700">
              <div className="mb-2 overflow-hidden rounded-md bg-gray-100 dark:bg-gray-700">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Eco-Friendly Water Bottle"
                  width={200}
                  height={200}
                  className="h-40 w-full object-contain"
                />
              </div>
              <h3 className="mb-1 font-semibold">Eco-Friendly Water Bottle</h3>
              <p className="mb-1 text-sm text-gray-500 dark:text-gray-400">Accessories</p>
              <p className="mb-2 font-bold">₱1,250</p>
              <Button className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">
                Add to Cart
              </Button>
            </div>

            <div className="rounded-lg border bg-white p-3 dark:bg-gray-800 dark:border-gray-700">
              <div className="mb-2 overflow-hidden rounded-md bg-gray-100 dark:bg-gray-700">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Organic Cotton T-Shirt"
                  width={200}
                  height={200}
                  className="h-40 w-full object-contain"
                />
              </div>
              <h3 className="mb-1 font-semibold">Organic Cotton T-Shirt</h3>
              <p className="mb-1 text-sm text-gray-500 dark:text-gray-400">Clothing</p>
              <p className="mb-2 font-bold">₱999</p>
              <Button className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">
                Add to Cart
              </Button>
            </div>

            {/* More products would go here */}
          </div>
        </TabsContent>
        <TabsContent value="clothing">{/* Similar structure as "all" tab, but only with clothing items */}</TabsContent>
        <TabsContent value="accessories">
          {/* Similar structure as "all" tab, but only with accessory items */}
        </TabsContent>
      </Tabs>
    </Layout>
  )
}

