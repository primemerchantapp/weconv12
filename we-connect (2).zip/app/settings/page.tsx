"use client"

import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"

export default function SettingsPage() {
  return (
    <Layout>
      <div className="py-6">
        <h1 className="mb-6 text-3xl font-bold">Settings</h1>

        <Tabs defaultValue="account" className="mb-6">
          <TabsList className="grid w-full grid-cols-3 rounded-md bg-gray-100 dark:bg-gray-800">
            <TabsTrigger
              value="account"
              className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
            >
              Account
            </TabsTrigger>
            <TabsTrigger
              value="notifications"
              className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
            >
              Notifications
            </TabsTrigger>
            <TabsTrigger
              value="appearance"
              className="rounded-md data-[state=active]:bg-white data-[state=active]:text-gray-900 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-gray-100"
            >
              Appearance
            </TabsTrigger>
          </TabsList>
          <TabsContent value="account">
            <div className="mt-4 rounded-lg border bg-white p-6 dark:bg-gray-800 dark:border-gray-700">
              <h2 className="mb-4 text-xl font-bold">Profile Information</h2>
              <p className="mb-6 text-gray-600 dark:text-gray-400">Update your account information.</p>

              <div className="mb-4 space-y-2">
                <label htmlFor="name" className="block font-medium">
                  Name
                </label>
                <Input
                  id="name"
                  defaultValue="Jasmine Dela Cruz"
                  className="w-full dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"
                />
              </div>

              <div className="mb-4 space-y-2">
                <label htmlFor="username" className="block font-medium">
                  Username
                </label>
                <Input
                  id="username"
                  defaultValue="janesmith"
                  className="w-full dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"
                />
              </div>

              <div className="mb-4 space-y-2">
                <label htmlFor="email" className="block font-medium">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  defaultValue="jane.smith@example.com"
                  className="w-full dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"
                />
              </div>

              <div className="mb-6 space-y-2">
                <label htmlFor="bio" className="block font-medium">
                  Bio
                </label>
                <Textarea
                  id="bio"
                  defaultValue="Community advocate passionate about sustainable living."
                  className="w-full dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"
                />
              </div>

              <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">
                Save Changes
              </Button>
            </div>
          </TabsContent>
          <TabsContent value="notifications">
            <div className="mt-4 rounded-lg border bg-white p-6 dark:bg-gray-800 dark:border-gray-700">
              <h2 className="mb-4 text-xl font-bold">Notification Preferences</h2>
              <p className="mb-6 text-gray-600 dark:text-gray-400">Manage how you receive notifications.</p>

              {/* Notification settings would go here */}
              <p className="text-gray-500 dark:text-gray-400">Notification settings coming soon.</p>
            </div>
          </TabsContent>
          <TabsContent value="appearance">
            <div className="mt-4 rounded-lg border bg-white p-6 dark:bg-gray-800 dark:border-gray-700">
              <h2 className="mb-4 text-xl font-bold">Appearance Settings</h2>
              <p className="mb-6 text-gray-600 dark:text-gray-400">Customize how the app looks for you.</p>

              {/* Appearance settings would go here */}
              <p className="text-gray-500 dark:text-gray-400">Appearance settings coming soon.</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  )
}

