import { Layout } from "@/components/layout"

export default function ConnectHubPage() {
  return (
    <Layout>
      <div className="py-6">
        <h1 className="text-3xl font-bold">ConnectHub</h1>
        <p className="mt-4">Connect with other users and expand your network.</p>
      </div>
    </Layout>
  )
}

