import { Layout } from "@/components/layout"

export default function IntegrationPage() {
  return (
    <Layout>
      <div className="py-6">
        <h1 className="text-3xl font-bold">Integration</h1>
        <p className="mt-4">Manage your integrations with other services and platforms.</p>
      </div>
    </Layout>
  )
}

