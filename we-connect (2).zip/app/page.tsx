import Image from "next/image"
import Link from "next/link"
import { Layout } from "@/components/layout"

export default function Home() {
  return (
    <Layout>
      <div className="py-6">
        {/* Hero Section */}
        <div className="mb-8 rounded-lg bg-blue-600 p-6 text-white dark:bg-blue-800">
          <h1 className="mb-4 text-3xl font-bold">Welcome to We Connect</h1>
          <p className="mb-6 text-lg">Your platform for community engagement, campaigns, and content creation.</p>
          <Link
            href="/get-started"
            className="inline-block rounded-md bg-white px-6 py-3 font-semibold text-blue-600 transition hover:bg-gray-100 dark:bg-gray-200 dark:text-blue-800 dark:hover:bg-gray-300"
          >
            Get Started
          </Link>
        </div>

        {/* Featured Content */}
        <h2 className="mb-4 text-2xl font-bold">Featured Content</h2>
        <div className="mb-8 overflow-hidden rounded-lg">
          <div className="relative">
            <Image
              src="/placeholder.svg?height=400&width=800"
              alt="Create Engaging Content"
              width={800}
              height={400}
              className="h-[400px] w-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6 text-white">
              <h3 className="mb-2 text-2xl font-bold">Create Engaging Content</h3>
              <p>Learn how to create content that connects</p>
            </div>
          </div>
        </div>

        {/* Trending Campaigns */}
        <h2 className="mb-4 text-2xl font-bold">Trending Campaigns</h2>
        <div className="mb-8 overflow-hidden rounded-lg">
          <Image
            src="/placeholder.svg?height=400&width=800"
            alt="Trending Campaign"
            width={800}
            height={400}
            className="h-[400px] w-full object-cover"
          />
        </div>
      </div>
    </Layout>
  )
}

